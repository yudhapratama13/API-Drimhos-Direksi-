<?php 

	include('config.php');

    $start    = $_POST['start'];
    $end      = $_POST['end'];
    $kelas    = $_POST['kelas'];
    $namaToko = $_POST['namaToko'];
    
    $toko = mysql_query("SELECT * FROM toko WHERE toko_name = '$namaToko' ");
    $db   = mysql_fetch_array($toko);
    
    //--------Koneksi Database-------------
    $koneksi    = mysql_connect("localhost", "".$db['username']."", "".$db['password']."");
    mysql_select_db("".$db['database_name']."", $koneksi);
    //--------Koneksi Database-------------

    if($kelas == 'Loyal'){
        $query = mysql_query("SELECT * FROM costumers WHERE status_costumer_active BETWEEN '$start' AND '$end' AND jumlah_transaksi > 5");
        $jumlah_costumer_cos = "0";
        $jumlah_buyer_cos    = "0";
        $jumlah_loyal_cos    = mysql_num_rows($query);
    }
    elseif($kelas == 'Costumer'){
        $query = mysql_query("SELECT * FROM costumers WHERE status_costumer_active BETWEEN '$start' AND '$end' AND jumlah_transaksi BETWEEN 2 and 5");
        $jumlah_buyer_cos    = "0";
        $jumlah_loyal_cos    = "0";
        $jumlah_costumer_cos = mysql_num_rows($query);
    }
    elseif($kelas == 'Buyer'){
        $query = mysql_query("SELECT * FROM costumers WHERE status_costumer_active BETWEEN '$start' AND '$end' AND jumlah_transaksi = 1");
        $jumlah_loyal_cos    = "0";
        $jumlah_costumer_cos = "0";
        $jumlah_buyer_cos    = mysql_num_rows($query);
    }
    else{
        $query = mysql_query("SELECT * FROM costumers WHERE status_costumer_active BETWEEN '$start' AND '$end'");
        
        $loyal = mysql_query("SELECT * FROM costumers WHERE status_costumer_active BETWEEN '$start' AND '$end' AND jumlah_transaksi > 5");
        
        $costumer = mysql_query("SELECT * FROM costumers WHERE status_costumer_active BETWEEN '$start' AND '$end' AND jumlah_transaksi BETWEEN 2 and 5");
        
        $buyer = mysql_query("SELECT * FROM costumers WHERE status_costumer_active BETWEEN '$start' AND '$end' AND jumlah_transaksi = 1");
        
        $jumlah_loyal_cos    = mysql_num_rows($loyal);
        $jumlah_costumer_cos = mysql_num_rows($costumer);
        $jumlah_buyer_cos    = mysql_num_rows($buyer);
    }

	$json  = array();
	$row   = array(loyal=>$jumlah_loyal_cos, costumer=>$jumlah_costumer_cos, buyer=>$jumlah_buyer_cos);
		$json[] = $row;
	
	echo json_encode($json);
	mysql_close($connect);

?>