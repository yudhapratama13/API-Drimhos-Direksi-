<?php 

	include('config.php');
	
	$x = $_POST['post'];

	$query = mysql_query("SELECT * FROM toko ORDER BY toko_name ASC");
	
	$result = array();
	
	while($row = mysql_fetch_assoc($query)){
		array_push($result,array(
			'toko_name'=>$row['toko_name'],
			'toko_id'  =>$row['toko_id']
		));
	}
	
	echo json_encode(array('result'=>$result));
	
	mysql_close($connect);

?>