<?php

    if($blnAkhir == 'Jan'){
        $bulanAkhir = '2';
    }
    elseif($blnAkhir == 'Feb'){
        $bulanAkhir = '3';
    }
    elseif($blnAkhir == 'Mar'){
        $bulanAkhir = '4';
    }
    elseif($blnAkhir == 'Apr'){
        $bulanAkhir = '5';
    }
    elseif($blnAkhir == 'May'){
        $bulanAkhir = '6';
    }
    elseif($blnAkhir == 'Jun'){
        $bulanAkhir = '7';
    }
    elseif($blnAkhir == 'Jul'){
        $bulanAkhir = '8';
    }
    elseif($blnAkhir == 'Aug'){
        $bulanAkhir = '9';
    }
    elseif($blnAkhir == 'Sep'){
        $bulanAkhir = '10';
    }
    elseif($blnAkhir == 'Oct'){
        $bulanAkhir = '11';
    }
    elseif($blnAkhir == 'Nov'){
        $bulanAkhir = '12';
    }
    else{
        $bulanAkhir = '13';
    }

?>