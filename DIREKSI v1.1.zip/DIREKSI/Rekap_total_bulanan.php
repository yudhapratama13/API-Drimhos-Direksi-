<?php 
   
    include('config.php');

    $date_start = date("Y-m-01");
    $date_end   = date("Y-m-d");
    
    //echo date("Y-m-d", mktime(0, 0, 0, 2, 0, 2017));
   
	$query1 = mysql_query("SELECT * FROM toko ORDER BY toko_name ASC");
	$total  = mysql_num_rows($query1);

	$data   = array();
	$tko    = array();
	$db_usr = array();
	$db_pas = array();
	$db_nme = array();
	while ($row1 = mysql_fetch_assoc($query1)) {
		$data[]   = $row1['toko_id'];
		$tko[]    = $row1['toko_name'];
		$db_usr[] = $row1['username'];
		$db_pas[] = $row1['password'];
		$db_nme[] = $row1['database_name'];
	}
    
    $json  = array();
    for($i=0; $i < $total; $i++){
        
        $id_tko = $data[$i];
        $nm_tko = $tko[$i];
        $dbUsr  = $db_usr[$i];
        $dbPas  = $db_pas[$i];
        $dbName = $db_nme[$i];
        
        //--------Koneksi Database-------------
        $koneksi    = mysql_connect("localhost", "".$dbUsr."", "".$dbPas."");
        mysql_select_db("".$dbName."", $koneksi);
        
        //------Poin--------------
        $query_poin = mysql_query("SELECT product_title_for_recap, SUM(transaction_amount) AS total, product_point, transactions_amount.transaction_id AS id_produk FROM transactions INNER JOIN transactions_amount ON transactions_amount.transaction_id = transactions.transaction_id INNER JOIN products ON products.product_id = transactions_amount.product_id WHERE transaction_date BETWEEN '$date_start' AND '$date_end' GROUP BY transactions_amount.product_id ORDER BY transactions.transaction_id ASC");
        
        $batas = mysql_num_rows($query_poin);
     
        $tot = array();
        while ($row_poin = mysql_fetch_assoc($query_poin)) {
		$tot[] = $row_poin['product_title_for_recap'];
	    }
	    
	    $poin_total = 0;
	    for($x=0; $x < $batas; $x++){
	        $id_pro = $tot[$x];

	        $query_poin = mysql_query("SELECT product_title_for_recap, SUM(transaction_amount) AS total, product_point FROM transactions INNER JOIN transactions_amount ON transactions_amount.transaction_id = transactions.transaction_id INNER JOIN products ON products.product_id = transactions_amount.product_id WHERE transaction_date BETWEEN '$date_start' AND '$date_end' AND  product_title_for_recap = '$id_pro' GROUP BY transactions_amount.product_id ORDER BY transactions.transaction_id ASC");
	        
	        $qPoin = mysql_fetch_array($query_poin);
	        $poin  = $qPoin['total'] * $qPoin['product_point'];
	        $poin_total = $poin_total + $poin;
	    }
	    
	    //-----Income---------------
	    $query_bri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'bri' AND transaction_date BETWEEN '$date_start' AND '$date_end'");
	    $bri = mysql_fetch_array($query_bri);
	    
	    $query_bni = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'bni' AND transaction_date BETWEEN '$date_start' AND '$date_end'");
	    $bni = mysql_fetch_array($query_bni);
	    
	    $query_mandiri = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'mandiri' AND transaction_date BETWEEN '$date_start' AND '$date_end'");
	    $mandiri = mysql_fetch_array($query_mandiri);
	    
	    $query_bca = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'bca' AND transaction_date BETWEEN '$date_start' AND '$date_end'");
	    $bca = mysql_fetch_array($query_bca);
	    
	    $query_cash = mysql_query("SELECT COALESCE(SUM(total_price), 0) AS total FROM transactions WHERE payment = 'cash' AND transaction_date BETWEEN '$date_start' AND '$date_end'");
	    $cash = mysql_fetch_array($query_cash);
	    
	    $totalIncome = $bri['total'] + $bni['total'] + $mandiri['total'] + $bca['total'] + $cash['total'];
	    
	    //------Expense------------------------------
	    $query_expense = mysql_query("SELECT * FROM transactions WHERE transaction_date BETWEEN '$date_start' AND '$date_end' ORDER BY transaction_id ASC");
        
        $batas_ex = mysql_num_rows($query_expense);
        
        $tot_ex = array();
        while ($row_ex = mysql_fetch_assoc($query_expense)) {
		$tot_ex[] = $row_ex['transaction_id'];
	    }
	    
	    $totale = 0;
	    $tot_shipping = 0;
	    for($j=0; $j < $batas_ex; $j++){
	        $id_transak = $tot_ex[$j];
            
	        $query_ex = mysql_query("SELECT * FROM transactions WHERE transaction_id = '$id_transak' ");
	        
	        $query_ex1 = mysql_query("SELECT * FROM transactions INNER JOIN transactions_amount ON transactions_amount.transaction_id = transactions.transaction_id INNER JOIN products ON products.product_id = transactions_amount.product_id WHERE transactions_amount.transaction_id = '$id_transak' ORDER BY transactions.transaction_id ASC");
	        $batas_ex1 = mysql_num_rows($query_ex1);
	
	        
	        $tot_ex1 = array();
	        while($row_ex1 = mysql_fetch_assoc($query_ex1)){
	            $tot_ex1[] = $row_ex1['transactions_amount_id'];
	        }
	        
	        $tot_ship = 0;
	        $ex_total = 0;
	        for($a=0; $a < $batas_ex1; $a++){
	            $productName = $tot_ex1[$a];
	            
	            $cek = mysql_query("SELECT * FROM transactions INNER JOIN transactions_amount ON transactions_amount.transaction_id = transactions.transaction_id INNER JOIN products ON products.product_id = transactions_amount.product_id WHERE 	transactions_amount_id = '$productName' ORDER BY transactions.transaction_id ASC");
	            $cekData = mysql_fetch_array($cek);
	            
	            $expense  = $cekData['transaction_amount'] * $cekData['product_base_price'];
	            $ex_total = $ex_total + $expense;
	            
	        }
	        
	        $qExpense  = mysql_fetch_array($query_ex);
	        $tot_shipping = $tot_shipping + $qExpense['shipping_fee'];
	        
	        $total_ex_all = $qExpense['shipping_fee'] + $ex_total;
	         
	            
	        $totale1 = $qExpense['shipping_fee'] + $ex_total;
	        $totale = $totale + $totale1;
	        //echo $id_transak.": ".$totale1.", ";   
	    }
              //echo $totale.", ";
        
        //--------Gross Profit--------------
        $gross_profit = $totalIncome - $totale;
        
        //-------------Total Cost------------
        $qFinance = mysql_query("SELECT COALESCE(SUM(finance_amount),0) AS total_finance FROM finance WHERE finance_date BETWEEN '$date_start' AND '$date_end' AND status = 'active' ORDER BY finance_date ASC");
        $finance = mysql_fetch_array($qFinance);
        $totCost = $finance['total_finance'];
        
        //--------------Profit----------------
        $profit = $gross_profit - $totCost;
        
        $row = array(toko_id=>$id_tko, toko_name=>$nm_tko, poin=>$poin_total, income=>$totalIncome, expense=>$totale, gross_profit=>$gross_profit, total_cost=>$totCost, profit=>$profit);
        $json[] = $row;
        
        
    }
    
    echo json_encode($json);
    mysql_close($connect);
?>