<?php 
   
    include('config.php');
   
    $blnMulai = $_POST['blnMulai'];
    $thnMulai = $_POST['thnMulai'];
    
    $blnAkhir = $_POST['blnAkhir'];
    $thnAkhir = $_POST['thnAkhir'];
    
    include('Check_bulan_tahun_awal.php');
    include('Check_bulan_tahun_akhir.php');
    
    $date_start = $thnMulai."-".$bulanMulai."-01";
    $date_end   = date("Y-m-d", mktime(0, 0, 0, $bulanAkhir, 0, $thnAkhir));
   
    //$date_start = date("Y-m-01");
    //$date_end   = date("Y-m-d");
    
	$query1 = mysql_query("SELECT * FROM toko ORDER BY toko_name ASC");
	$total  = mysql_num_rows($query1);

	$data   = array();
	$tko    = array();
	$db_usr = array();
	$db_pas = array();
	$db_nme = array();
	while ($rowx = mysql_fetch_assoc($query1)) {
		$data[]   = $rowx['toko_id'];
		$tko[]    = $rowx['toko_name'];
		$db_usr[] = $rowx['username'];
		$db_pas[] = $rowx['password'];
		$db_nme[] = $rowx['database_name'];
	}
    
    $json  = array();
    $data_json = array();
    for($i=0; $i < $total; $i++){
        
        $id_tko = $data[$i];
        $nm_tko = $tko[$i];
        $dbUsr  = $db_usr[$i];
        $dbPas  = $db_pas[$i];
        $dbName = $db_nme[$i];
        
        //1--------Start Koneksi Database-------------
        
        $koneksi    = mysql_connect("localhost", "".$dbUsr."", "".$dbPas."");
        mysql_select_db("".$dbName."", $koneksi);
        
        //1******* End Koneksi Database **************
        
        //2------- Start Cek Per Cs --------------
        $cs = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' ORDER BY user_name ASC");
    	$batasCs = mysql_num_rows($cs);
    
    	$datax  = array();
    	while ($row1 = mysql_fetch_assoc($cs)) {
    		$datax[] = $row1['user_id'];
    	}
    	
    	//2****** End Cek Per Cs *******************
    	
    	$totLeads = 0;
    	$totClosing = 0;
    	//3-----Start Batas Cs-----------------
    	for($j=0; $j < $batasCs; $j++){
    	    
    	    $user_id = $datax[$j];
        
            //4-------- Start Leads  -------------
            $queryM = mysql_query ("SELECT SUM(leads_amount) AS leadsM FROM leads WHERE user_id = '$user_id' AND leads_date BETWEEN '$date_start' AND '$date_end'");
            $data_m = mysql_fetch_array($queryM);
            
            $tot_leadsM = $data_m['leadsM'];
            
            if(empty($tot_leadsM)){
                $totM = "0";
            }
            else{
                $totM = $tot_leadsM;
            }
            
            $totLeads = $totLeads + $totM;
            
            //4********* End Leads *****************
            
            $cs_cek = mysql_query("SELECT * FROM users WHERE rule_user='costumer servis' AND user_id = '$user_id' ORDER BY user_name ASC");
    	    $data_cs = mysql_fetch_array($cs_cek);
    	    $nama = $data_cs['user_name'];
	    
    	    //5------- Start Closing(Poin) ---------
    	    $nama_barang_query_m = mysql_query("SELECT * FROM transactions INNER JOIN transactions_amount ON transactions.transaction_id = transactions_amount.transaction_id INNER JOIN products ON transactions_amount.product_id = products.product_id WHERE transactions.user_id = '$user_id' AND transaction_date BETWEEN '$date_start' AND '$date_end' ");
            $jml_total_m = mysql_num_rows($nama_barang_query_m);
            
            $poin_total_closing_m = 0;
            
            for($k=0; $k < $jml_total_m; $k++){
                $data_closing_m = mysql_fetch_array($nama_barang_query_m);
                
                $jumlah_m = $data_closing_m['transaction_amount'];
                $poin_m   = $data_closing_m['product_point'];
                
                $poin_jmlh_m = $jumlah_m * $poin_m;
                
                $poin_total_closing_m = $poin_total_closing_m + $poin_jmlh_m;
            }
            
            $totClosing = $totClosing + $poin_total_closing_m;
            
            //5******** End Closing (Poin) *************
            
        
    	}
    	//3********* End Batas Cs ************
    	
    	//6-------- Start Conversion -----------
        if ($totLeads == 0) {

            if ($totClosing != 0) {
                $conversion = 100;
            } else {
                $conversion = "0";
            }

        } else {
            $conversion_hari = ($totClosing * 100 )/ $totLeads; 
            $conversion = number_format ($conversion_hari,0);
        }
        //6********* End Conversion ***************
    	
        
        $row = array(toko_id=>$id_tko, toko_name=>$nm_tko, leads=>$totLeads, closing=>$totClosing, conversion=>$conversion);
        $json[] = $row;
        
    }
    
      $json_data = json_decode(json_encode($json),true);
    //echo count($json_data);
    
    foreach ($json_data as $key => $isi) {
        $leads[$key]=$isi['leads'];
        $closing[$key]=$isi['closing'];
        $conver[$key]=$isi['conversion'];
        $toko[$key]=$isi['toko_name'];
        $id_toko[$key]=$isi['toko_id'];
    }
    
    array_multisort($closing,SORT_DESC,$leads,SORT_DESC,$conver,$toko,$id_toko,$json_data);
    
    foreach ($json_data as $item) {
    
    $baris_data = array(toko_id=>$item['toko_id'], toko_name=>$item['toko_name'], leads=>$item['leads'], closing=>$item['closing'], conversion=>$item['conversion']);
    $data_json[] = $baris_data;
        
    }
    
    echo json_encode($data_json);
    mysql_close($connect);
    
?>