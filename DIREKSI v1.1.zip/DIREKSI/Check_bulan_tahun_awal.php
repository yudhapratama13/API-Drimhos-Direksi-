<?php

    if($blnMulai == 'Jan'){
        $bulanMulai = '1';
    }
    elseif($blnMulai == 'Feb'){
        $bulanMulai = '2';
    }
    elseif($blnMulai == 'Mar'){
        $bulanMulai = '3';
    }
    elseif($blnMulai == 'Apr'){
        $bulanMulai = '4';
    }
    elseif($blnMulai == 'May'){
        $bulanMulai = '5';
    }
    elseif($blnMulai == 'Jun'){
        $bulanMulai = '6';
    }
    elseif($blnMulai == 'Jul'){
        $bulanMulai = '7';
    }
    elseif($blnMulai == 'Aug'){
        $bulanMulai = '8';
    }
    elseif($blnMulai == 'Sep'){
        $bulanMulai = '9';
    }
    elseif($blnMulai == 'Oct'){
        $bulanMulai = '10';
    }
    elseif($blnMulai == 'Nov'){
        $bulanMulai = '11';
    }
    else{
        $bulanMulai = '12';
    }

?>