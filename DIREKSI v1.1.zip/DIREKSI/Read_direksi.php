<?php 
	
	include ('config.php');

	$id_direksi = $_POST['id_direksi'];

	class emp{}

	if (empty($id_direksi)) {
		$response = new emp();
		$response->success = 0;
		$response->message = "Error Mengambil Data";
		die(json_encode($response));
	}
	else{

		$query = mysql_query("SELECT * FROM users WHERE user_id = '$id_direksi' ");
		$row   = mysql_fetch_array($query);
		
		$query1 = mysql_query("SELECT * FROM toko ORDER BY toko_name ASC");
		$total  = mysql_num_rows($query1);
		
		$data   = array();
		$tko    = array();
    	$db_usr = array();
    	$db_pas = array();
    	$db_nme = array();
    	while ($row1 = mysql_fetch_assoc($query1)) {
    		$data[]   = $row1['toko_id'];
    		$tko[]    = $row1['toko_name'];
    		$db_usr[] = $row1['username'];
    		$db_pas[] = $row1['password'];
    		$db_nme[] = $row1['database_name'];
    	}
        	
    	$total_plg  = 0;
    	$total_tran = 0;
    	for($i =0; $i < $total; $i++){
    	    $id_tko = $data[$i];
        $nm_tko = $tko[$i];
        $dbUsr  = $db_usr[$i];
        $dbPas  = $db_pas[$i];
        $dbName = $db_nme[$i];
        
        //--------Koneksi Database-------------
        $koneksi    = mysql_connect("localhost", "".$dbUsr."", "".$dbPas."");
        mysql_select_db("".$dbName."", $koneksi);
    	    
    	    $plg = mysql_query("SELECT * FROM costumers");
    	    $tot_plg = mysql_num_rows($plg);
    	    
    	    $transaction = mysql_query("SELECT * FROM transactions");
    	    $tot_transak = mysql_num_rows($transaction);
    	    
    	    $total_plg  = $total_plg + $tot_plg;
    	    $total_tran = $total_tran + $tot_transak;
    	    
    	}
		
		//$query2 = mysql_query("SELECT * FROM costumers");
		//$query3 = mysql_query("SELECT * FROM transactions");

		if (!empty($row)) {
		 	$response = new emp();
		 	$response->success = 1;
		 	$response->user_id     	     = $row['user_id'];
		 	$response->user_name    	 = $row['user_name'];
		 	$response->user_nickname 	 = $row['user_nickname'];
		 	$response->user_phone_number = $row['user_phone_number'];
		 	$response->user_email 	     = $row['user_email'];
		 	$response->user_password	 = $row['user_password'];
		 	$response->user_picture      = $row['user_picture'];
		 	$response->jml_toko          = mysql_num_rows($query1);
		 	$response->jml_pelanggan     = $total_plg;
		 	$response->jml_transaksi     = $total_tran;
		 	die(json_encode($response));
		 }
		 else{
		 	$response = new emp();
		 	$response->success = 0;
		 	$response->message = "Error Mengambil Data";
		 	die(json_encode($response));
		 } 

	}

?>